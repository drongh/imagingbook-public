
See package imagingbook.color3 for the associated code.
