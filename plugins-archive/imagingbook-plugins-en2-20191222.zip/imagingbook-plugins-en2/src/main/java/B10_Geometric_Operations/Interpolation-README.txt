
See package imagingbook.lib.interpolation for the associated code.
