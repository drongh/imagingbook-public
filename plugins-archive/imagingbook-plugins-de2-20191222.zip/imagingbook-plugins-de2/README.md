# imagingbook-plugins-de2

This repository provides Java source code supplementing
the digital image processing books by W. Burger & M. J. Burge
(see [imagingbook.com](https://imagingbook.com) for details).

Main repository: [imagingbook-public](https://github.com/imagingbook/imagingbook-public)


Javadoc: https://imagingbook.github.io/imagingbook-plugins-de2/javadoc/
